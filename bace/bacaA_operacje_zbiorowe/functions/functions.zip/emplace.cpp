//Weronika Zygis
void Insert(char*, int*);

void Emplace (char* input, int* result_set){
    *result_set = 0;
    Insert(input, result_set);
}

