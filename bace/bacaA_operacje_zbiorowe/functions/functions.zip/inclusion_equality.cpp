//Weronika Zygis
bool Inclusion(int A, int B){
    //A & B = A
    return ((A & B)==A);
}

bool Equality(int A, int B){
    return A==B;
}
