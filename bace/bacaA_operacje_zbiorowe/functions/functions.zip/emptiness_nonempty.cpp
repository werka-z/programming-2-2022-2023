//Weronika Zygis
bool Emptiness (int set){
    return set == 0;
}

bool Nonempty(int set){
    return set != 0;
}
